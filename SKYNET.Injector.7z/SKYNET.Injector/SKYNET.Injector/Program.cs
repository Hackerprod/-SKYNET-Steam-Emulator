﻿using System;
using System.IO;
using System.Runtime.InteropServices;

namespace SKYNET.Injector
{
    public class Program
    {
        static void Main(string[] args)
        {
            if (args.Length == 0) return;
            var ExecutablePath = args[0];
            var Parameters = args[1];
            var DllPath = args[2];

            if (!File.Exists(ExecutablePath))
            {
                Console.WriteLine($"File not exists {ExecutablePath}");
                return;
            }

            Console.WriteLine("ExecutablePath: " + ExecutablePath + Environment.NewLine + "Parameters: " + Parameters + Environment.NewLine + "DllPath: " + DllPath);
            var Result = DLLInjector.CreateAndInject(ExecutablePath, Parameters, DllPath);
            if (Result)
            {
                Console.WriteLine($"Dll injected successfully in process with result {Native.GetLastError()}");
            }
            else
            {
                Console.WriteLine($"Error injecting Dll in process with result {Native.GetLastError()}");
            }
        }

        [DllExport(CallingConvention = CallingConvention.Cdecl)]
        public static void Write(string v)
        {

        }
    }
}
