﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SKYNET
{
    public class DLLInjector
    {
        public static bool CreateAndInject(string ExecutablePath, string Parameters, string DllPath)
        {
            var success = Native.CreateProcess(ExecutablePath, Parameters, IntPtr.Zero, IntPtr.Zero, bInheritHandles: false, ProcessCreationFlags.CREATE_SUSPENDED, IntPtr.Zero, null, out var STARTUPINFO, out var ProcessInfo);

            if (success)
            {
                success = InjectDll((int)ProcessInfo.dwProcessId, DllPath);
                Native.ResumeThread(ProcessInfo.hThread);
            }

            return success;
        }

        public static bool InjectDll(int ProcessID, string DllPath)
        {
            Thread.Sleep(150);
            IntPtr procHandle = Native.OpenProcess((int)ProcessAccess.AllAccess, bInheritHandle: false, ProcessID);
            IntPtr ModuleHandle = Native.GetModuleHandle("kernel32.dll");
            IntPtr LibraryAddress = Native.GetProcAddress(ModuleHandle, "LoadLibraryA");
            var dwSize = (uint)((DllPath.Length + 1) * Marshal.SizeOf(typeof(char)));
            IntPtr allocateMemoryAdress = Native.VirtualAllocEx(procHandle, IntPtr.Zero, dwSize, 12288u, 4u);
            Native.WriteProcessMemory(procHandle, allocateMemoryAdress, Encoding.Default.GetBytes(DllPath), dwSize, out _);
            var thread = Native.CreateRemoteThread(procHandle, IntPtr.Zero, 0u, LibraryAddress, allocateMemoryAdress, 0u, IntPtr.Zero);
            return thread != IntPtr.Zero;
        }

        #region Native Methods

        #endregion
    }
}
