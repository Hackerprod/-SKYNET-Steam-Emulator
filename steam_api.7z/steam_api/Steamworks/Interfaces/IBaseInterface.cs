﻿namespace SKYNET.Interface
{
    public interface ISteamInterface
    {
    }
}