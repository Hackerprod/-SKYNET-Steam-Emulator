﻿using SKYNET.Steamworks.Types;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SKYNET.Steamworks.Helpers
{
    public static class SteamworksExtenctions
    {
        public static string GetString(this UTF8StringHandle UTF8String)
        {
            return "";
        }
    }
}
